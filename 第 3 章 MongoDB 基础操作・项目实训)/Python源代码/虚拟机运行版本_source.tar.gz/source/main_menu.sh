#!/usr/bin/env bash
cd /root/source || exit 1
export LANG=C.UTF-8 LC_ALL=C.UTF-8
cat <<'INPUT' | python3 main.py
1
数据结构

2
80
200

3
计算机
编程

4

5
9787115400001
MongoDB 权威指南（第3版）
Kristina Chodorow
人民邮电出版社
计算机
128
6
4.6
MongoDB,数据库,NoSQL

6
9787115428028
17
4.7

7
9787115400001
y

8
R20240003
9787115428028

9
R20240003
9787115428028

10
张

11

12

13

14
m

15

16

abc

0
INPUT
echo "### exit code = $?"
