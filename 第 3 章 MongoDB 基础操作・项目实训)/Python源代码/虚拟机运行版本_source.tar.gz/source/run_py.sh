#!/bin/bash
# 在虚拟机 NoSQL01 中依次运行 ST-5.1 ~ ST-5.6 六个 PyMongo 程序
export LANG=C.UTF-8 LC_ALL=C.UTF-8
mkdir -p /root/source /root/backup/pymongo
cd /root/source
for f in t1_basic_crud t2_search_paging t3_aggregate t4_import_export t5_platform t6_data_importer t7_scheduler; do
  echo "########################################################################"
  echo "###  python3 ${f}.py   @ $(date '+%Y-%m-%d %H:%M:%S')"
  echo "########################################################################"
  if [ "$f" = "t4_import_export" ]; then
    python3 ${f}.py --restore
  elif [ "$f" = "t5_platform" ]; then
    python3 ${f}.py --demo
  elif [ "$f" = "t6_data_importer" ]; then
    python3 ${f}.py /root/data/books.json
  else
    python3 ${f}.py
  fi
  echo "### exit code = $?"
done
echo "########################################################################"
echo "### 全部 PyMongo 程序执行完毕"
echo "########################################################################"
ls -l /root/backup/pymongo
