#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ST-5.6  图书情报检索与统计平台 —— 导入图书并校验数据完整性（PyMongo）
文件：t6_data_importer.py
运行：python3 t6_data_importer.py                      （导入 + 校验）
      python3 t6_data_importer.py /root/data/books.json --dry-run   （只校验不写库）
说明：本程序读取由 mongoimport 使用的同一份 books.json（MongoDB Extended JSON），
      先用 bson.json_util 解析，再按“字段完整性 / 类型 / 取值域 / 唯一性 / 引用一致性”
      五类规则做数据质量校验，把不合规记录写入 rejected.json，把合规记录批量 upsert 入库，
      最后输出导入报告，用于说明“导入数据为什么要做完整性校验”。
"""
import os
from urllib.parse import quote_plus
import sys
import json
import datetime

import pymongo
from pymongo import MongoClient, UpdateOne
from pymongo.errors import BulkWriteError
from bson import json_util

URI = os.environ.get("MONGO_URI", ("mongodb://libWriter:%s@127.0.0.1:27017/?authSource=library" % quote_plus("Writer@2026")))
SRC = sys.argv[1] if len(sys.argv) > 1 and not sys.argv[1].startswith("-") else "/root/data/books.json"
DRY = "--dry-run" in sys.argv
OUTDIR = os.environ.get("REJECT_DIR", "/root/backup/pymongo")
BATCH = 50

REQUIRED = ["isbn", "title", "author", "publisher", "category", "price", "stock", "rating"]
CATEGORIES = {"计算机", "文学", "数学", "外语", "经济管理"}
ISBN_RE = __import__("re").compile(r"^97[89]\d{10}$")

print("=" * 72)
print(" ST-5.6  数据导入与完整性校验    (PyMongo %s)" % pymongo.version)
print("=" * 72)
print("  数据源 : %s" % SRC)
print("  运行模式: %s" % ("只校验不写库 (--dry-run)" if DRY else "校验 + 写入数据库"))


# ---------------------------------------------------------------- 读取源文件
with open(SRC, encoding="utf-8") as f:
    raw = json_util.loads(f.read())
print("\n[1] 读取源文件：解析到 %d 条图书文档" % len(raw))
print("    字段：%s" % ", ".join(sorted({k for d in raw for k in d})))


# ---------------------------------------------------------------- 校验规则
def check(doc, idx, isbn_seen, categories_ok):
    """返回 (是否通过, 错误列表)。"""
    errs = []
    # R1 必填字段完整性
    for k in REQUIRED:
        if k not in doc or doc[k] in (None, ""):
            errs.append("R1 缺少必填字段 %s" % k)
    # R2 类型正确性
    if not isinstance(doc.get("isbn"), str):
        errs.append("R2 isbn 不是字符串")
    if not isinstance(doc.get("price"), (int, float)):
        errs.append("R2 price 不是数值")
    if not isinstance(doc.get("stock"), int):
        errs.append("R2 stock 不是整数")
    if "tags" in doc and not isinstance(doc["tags"], list):
        errs.append("R2 tags 不是数组")
    if "borrow_count" in doc and not isinstance(doc["borrow_count"], int):
        errs.append("R2 borrow_count 不是整数")
    # R3 取值域合法性
    if isinstance(doc.get("price"), (int, float)) and not (0 < doc["price"] < 10000):
        errs.append("R3 price 超出合理范围 (0,10000)")
    if isinstance(doc.get("stock"), int) and doc["stock"] < 0:
        errs.append("R3 stock 为负")
    if isinstance(doc.get("rating"), (int, float)) and not (0 <= doc["rating"] <= 5):
        errs.append("R3 rating 不在 0~5")
    if doc.get("category") and doc["category"] not in CATEGORIES:
        errs.append("R3 category '%s' 不在枚举中" % doc["category"])
    # R4 唯一性
    if doc.get("isbn") in isbn_seen:
        errs.append("R4 isbn 重复（与第 %d 条相同）" % isbn_seen[doc["isbn"]])
    else:
        isbn_seen[doc["isbn"]] = idx
    # R5 格式规范（ISBN-13）
    if isinstance(doc.get("isbn"), str) and not ISBN_RE.match(doc["isbn"]):
        errs.append("R5 isbn 不符合 ISBN-13 格式")
    return (len(errs) == 0), errs


print("\n[2] 数据质量校验（R1 完整性 / R2 类型 / R3 取值域 / R4 唯一性 / R5 格式）")
isbn_seen = {}
good, bad = [], []
for i, d in enumerate(raw, 1):
    ok, errs = check(d, i, isbn_seen, CATEGORIES)
    (good if ok else bad).append((i, d, errs))
    flag = "PASS" if ok else "FAIL"
    print("   %2d. %-28s %-13s %s" % (i, flag, d.get("isbn", "-")[:13],
                                      "" if ok else "；".join(errs)))
print("\n   校验结果：通过 %d 条，不通过 %d 条" % (len(good), len(bad)))

if bad:
    os.makedirs(OUTDIR, exist_ok=True)
    p = os.path.join(OUTDIR, "rejected.json")
    with open(p, "w", encoding="utf-8") as f:
        json.dump([{"line": i, "errors": e, "doc": json_util.loads(json_util.dumps(d))}
                   for i, d, e in bad], f, ensure_ascii=False, indent=2, default=str)
    print("   不合规记录已写入 %s" % p)


# ---------------------------------------------------------------- 写入数据库
if DRY:
    print("\n[3] --dry-run 模式：跳过写库")
else:
    print("\n[3] 合规数据批量 upsert 入库（以 isbn 为业务主键，分批 %d 条）" % BATCH)
    client = MongoClient(URI, serverSelectionTimeoutMS=5000)
    col = client["library"]["books"]
    col.create_index([("isbn", 1)], unique=True, name="idx_isbn_unique")
    before = col.count_documents({})
    ins = upd = 0
    ops = []
    for i, d, _ in good:
        d = dict(d)
        d.pop("_id", None)          # _id 由数据库重新生成，避免与已有记录冲突
        d["imported_at"] = datetime.datetime.now()
        ops.append(UpdateOne({"isbn": d["isbn"]}, {"$set": d}, upsert=True))
    for s in range(0, len(ops), BATCH):
        try:
            r = col.bulk_write(ops[s:s + BATCH], ordered=False)
            ins += r.upserted_count
            upd += r.modified_count
        except BulkWriteError as e:
            ins += e.details.get("nUpserted", 0)
            upd += e.details.get("nModified", 0)
    after = col.count_documents({})
    print("    执行结果：新增 %d 条，更新 %d 条" % (ins, upd))
    print("    books 文档数 %d -> %d" % (before, after))

    # ------------------------------------------------------------ 复核
    print("\n[4] 导入后复核")
    print("    文档总数        : %d" % col.count_documents({}))
    print("    缺 title 记录    : %d" % col.count_documents({"title": {"$exists": False}}))
    print("    负库存记录       : %d" % col.count_documents({"stock": {"$lt": 0}}))
    dup = list(col.aggregate([
        {"$group": {"_id": "$isbn", "n": {"$sum": 1}}}, {"$match": {"n": {"$gt": 1}}},
        {"$count": "dup_isbn"}]))
    print("    重复 isbn 组数   : %d" % (dup[0]["dup_isbn"] if dup else 0))
    print("    本次导入标记条数 : %d" % col.count_documents({"imported_at": {"$exists": True}}))
    cat = list(col.aggregate([{"$group": {"_id": "$category", "n": {"$sum": 1}}}, {"$sort": {"n": -1}}]))
    print("    分类分布        : %s" % "、".join("%s %d 本" % (c["_id"], c["n"]) for c in cat))
    client.close()

print("\n[5] 导入与校验流程结束，程序正常退出")
