#!/usr/bin/env python3
# 合并重复出现的「菜单」块（只保留前两次），供文档与实验报告引用
import re
import sys

src_path = sys.argv[1] if len(sys.argv) > 1 else '/root/out_main_demo.txt'
dst_path = sys.argv[2] if len(sys.argv) > 2 else '/root/out_main_compact.txt'

src = open(src_path, encoding='utf-8').read()
lines = src.splitlines(True)
# 找出所有以 “请选择功能编号（0 退出）：” 结尾的菜单块起点（连续的 |...| 框线块）
menu_starts = []
i = 0
while i < len(lines):
    if lines[i].startswith('+-') and i + 1 < len(lines) and '图书情报检索与统计平台' in lines[i + 1]:
        j = i
        while j < len(lines) and '请选择功能编号' not in lines[j]:
            j += 1
        if j < len(lines):
            menu_starts.append((i, j))
            i = j + 1
            continue
    i += 1

print('菜单出现次数：', len(menu_starts))
out = []
last = 0
for idx, (s, e) in enumerate(menu_starts):
    out.extend(lines[last:s])
    if idx < 2:
        out.extend(lines[s:e + 1])
    else:
        out.append('[菜单]（同上，共 16 项功能，输入对应编号）\n')
        out.append(lines[e])
    last = e + 1
out.extend(lines[last:])
res = ''.join(out)
open(dst_path, 'w', encoding='utf-8').write(res)
print('原始 %d 字符 → 压缩 %d 字符' % (len(src), len(res)))
