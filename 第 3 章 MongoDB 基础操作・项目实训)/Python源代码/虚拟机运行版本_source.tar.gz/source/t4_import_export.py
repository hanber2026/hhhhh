#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ST-5.4  图书情报检索与统计平台 —— 批量导入与备份导出
文件：t4_import_export.py
运行：python3 t4_import_export.py            （导出备份 + 统计核对）
      python3 t4_import_export.py --restore  （额外演示“导出 -> 清空 -> 导入还原”）
说明：为满足“数据导入导出”的要求，本程序使用与 mongosh 等价的 PyMongo 方式实现：
      ① 逐文档批量导入（insert_many，分批 25 条，捕获 BulkWriteError 实现幂等）；
      ② 导出为 Extended JSON（bson.json_util，可被 mongoimport --mode=upsert 直接读回）；
      ③ 导出为 CSV，供 Excel 直接打开做二次统计；
      ④ 统计信息导出为 JSON 报告；
      ⑤ 清空后重新导入并核对条数，验证备份可用。
"""
import os
from urllib.parse import quote_plus
import sys
import csv
import json
from collections import Counter

import pymongo
from pymongo import MongoClient
from pymongo.errors import BulkWriteError
from bson import ObjectId, json_util

URI = ("mongodb://libWriter:%s@127.0.0.1:27017/?authSource=library" % quote_plus("Writer@2026"))
DB_NAME = "library"
OUT = os.environ.get("EXPORT_DIR", "/root/backup/pymongo")
BATCH = 25
COLLECTIONS = ["books", "readers", "borrow_logs"]

client = MongoClient(URI, serverSelectionTimeoutMS=5000)
db = client[DB_NAME]
os.makedirs(OUT, exist_ok=True)

print("=" * 72)
print(" ST-5.4  批量导入与备份导出    (PyMongo %s)" % pymongo.version)
print("=" * 72)
print("  数据库 : %s" % DB_NAME)
print("  输出目录: %s" % OUT)


# ---------------------------------------------------------------- 工具函数
def dump_ejson(name):
    """把集合导出为 MongoDB Extended JSON（一行一条，mongoimport 可直接读取）。"""
    path = os.path.join(OUT, "%s.ejson" % name)
    n = 0
    with open(path, "w", encoding="utf-8") as f:
        for doc in db[name].find({}):
            f.write(json_util.dumps(doc, json_options=json_util.CANONICAL_JSON_OPTIONS) + "\n")
            n += 1
    return path, n


def dump_csv(name, columns):
    """把集合导出为 CSV（表头 + 数据行），方便用 Excel 做二次核对。"""
    path = os.path.join(OUT, "%s.csv" % name)
    n = 0
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(columns)
        for doc in db[name].find({}):
            row = []
            for c in columns:
                v = doc.get(c, "")
                if isinstance(v, list):
                    v = "|".join(map(str, v))
                elif isinstance(v, ObjectId):
                    v = str(v)
                elif v is None:
                    v = ""
                row.append(v)
            w.writerow(row)
            n += 1
    return path, n


def load_ejson(name):
    """从 Extended JSON 文件读回文档（等价于 mongoimport）。"""
    path = os.path.join(OUT, "%s.ejson" % name)
    docs = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                docs.append(json_util.loads(line))
    return docs


def bulk_import(name, docs):
    """分批 insert_many 导入，遇到 _id 重复（E11000）的记录跳过，实现幂等导入。"""
    ok, dup = 0, 0
    for i in range(0, len(docs), BATCH):
        chunk = docs[i:i + BATCH]
        try:
            r = db[name].insert_many(chunk, ordered=False)
            ok += len(r.inserted_ids)
        except BulkWriteError as e:
            ok += e.details.get("nInserted", 0)
            dup += len([w for w in e.details.get("writeErrors", []) if w.get("code") == 11000])
    return ok, dup


# ---------------------------------------------------------------- 1. 导出
print("\n[1] 导出集合（Extended JSON + CSV）")
for name in COLLECTIONS:
    p, n = dump_ejson(name)
    print("    %-12s -> %-40s %3d 条  %6.1f KB" % (name, p, n, os.path.getsize(p) / 1024))

p, n = dump_csv("books", ["isbn", "title", "author", "publisher", "category",
                          "price", "stock", "rating", "tags", "borrow_count"])
print("    %-12s -> %-40s %3d 条" % ("books(csv)", p, n))
p, n = dump_csv("borrow_logs", ["reader_card", "book_isbn", "borrow_date", "return_date", "status"])
print("    %-12s -> %-40s %3d 条" % ("borrow_logs(csv)", p, n))

# ---------------------------------------------------------------- 2. 统计报告
print("\n[2] 生成统计报告 stats_report.json")
report = {}
for name in COLLECTIONS:
    report[name] = {"count": db[name].count_documents({}), "indexes": db[name].index_information().keys() and
                    list(db[name].index_information().keys())}
report["category"] = list(db["books"].aggregate([
    {"$group": {"_id": "$category", "n": {"$sum": 1}, "borrow": {"$sum": "$borrow_count"}}},
    {"$sort": {"n": -1}},
    {"$project": {"_id": 0, "category": "$_id", "n": 1, "borrow": 1}},
]))
report["status"] = list(db["borrow_logs"].aggregate([
    {"$group": {"_id": "$status", "n": {"$sum": 1}}}, {"$sort": {"n": -1}},
    {"$project": {"_id": 0, "status": "$_id", "n": 1}},
]))
report["generated_at"] = json_util.dumps(db.command("hello")["localTime"])[:0] or \
    str(db.command("hello")["localTime"].strftime("%Y-%m-%d %H:%M:%S"))

rpath = os.path.join(OUT, "stats_report.json")
with open(rpath, "w", encoding="utf-8") as f:
    json.dump(report, f, ensure_ascii=False, indent=2)
print("    -> %s" % rpath)
for name in COLLECTIONS:
    print("      %-12s %3d 条   索引 %d 个 : %s"
          % (name, report[name]["count"], len(report[name]["indexes"]),
             ", ".join(report[name]["indexes"])))
print("      分类统计 : %s" % "、".join("%s %d 本" % (x["category"], x["n"]) for x in report["category"]))
print("      借阅状态 : %s" % "、".join("%s %d 条" % (x["status"], x["n"]) for x in report["status"]))

# ---------------------------------------------------------------- 3. 幂等性验证
print("\n[3] 导入幂等性验证：重复导入 books.ejson")
docs = load_ejson("books")
before = db["books"].count_documents({})
ok, dup = bulk_import("books", docs)
after = db["books"].count_documents({})
print("    读入 %d 条，成功插入 %d 条，_id 重复被跳过 %d 条" % (len(docs), ok, dup))
print("    文档数 %d -> %d （未产生重复数据，幂等性成立）" % (before, after))

# ---------------------------------------------------------------- 4. 还原演练
if "--restore" in sys.argv:
    print("\n[4] 备份还原演练：清空 books -> 从备份文件重新导入 -> 核对")
    backup = load_ejson("books")
    db["books"].drop()
    db["books"].create_index([("isbn", 1)], unique=True, name="idx_isbn_unique")
    db["books"].create_index([("title", 1)], name="idx_title")
    db["books"].create_index([("category", 1)], name="idx_category")
    db["books"].create_index([("tags", 1)], name="idx_tags")
    db["books"].create_index([("category", 1), ("price", -1)], name="idx_category_price")
    print("    清空后 books 文档数 = %d" % db["books"].count_documents({}))
    ok, dup = bulk_import("books", backup)
    print("    重新导入：读入 %d 条 / 插入 %d 条 / 跳过 %d 条" % (len(backup), ok, dup))
    print("    还原后 books 文档数 = %d" % db["books"].count_documents({}))
    sample = db["books"].find_one({"isbn": "9787115428028"}, {"_id": 0, "title": 1, "price": 1, "stock": 1})
    print("    抽样核对 9787115428028 -> %s" % sample)
    print("    索引恢复情况: %s" % ", ".join(db["books"].index_information().keys()))
    cat = Counter(d["category"] for d in db["books"].find({}, {"category": 1}))
    print("    分类分布核对: %s" % "、".join("%s %d 本" % (k, v) for k, v in cat.most_common()))
    print("    结论：备份文件完整可用，还原后条数与分类分布与原始数据集一致。")

client.close()
print("\n[5] 全部导入导出任务完成，程序正常结束")
