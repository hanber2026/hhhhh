#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ST-5.7  图书情报检索与统计平台 —— 定期统计任务（可交给 cron 定时执行）
文件：t7_scheduler.py
运行：python3 t7_scheduler.py           执行一次统计任务
      crontab -e 加入：30 2 * * * /usr/bin/python3 /root/source/t7_scheduler.py >> /root/logs/t7.log 2>&1
说明：平台每晚需要刷新“分类统计表”“借阅统计表”，即周期性离线计算（类 MapReduce 的
      map(按维度分组) + reduce(聚合求和) 思想）。本程序用聚合管道完成同样的工作量，
      并把每次执行情况写入 platform_jobs 任务日志集合，便于运维追溯。
"""
import time
import datetime

import pymongo
from pymongo import MongoClient, DESCENDING

URI = "mongodb://libWriter:Writer%402026@127.0.0.1:27017/?authSource=library"
client = MongoClient(URI, serverSelectionTimeoutMS=5000)
db = client["library"]
books, readers, logs = db["books"], db["readers"], db["borrow_logs"]
jobs = db["platform_jobs"]

START = time.time()
print("=" * 72)
print(" ST-5.7  定期统计任务   %s   (PyMongo %s)"
      % (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), pymongo.version))
print("=" * 72)

# ---------------------------------------------------------------- 1. reduce 阶段：分类汇总
print("\n[1] map-reduce 思想实现：按 category 分组求和（reduce 结果写回 category_stats）")
pipeline_cate = [
    {"$group": {
        "_id": "$category",
        "book_count": {"$sum": 1},
        "total_stock": {"$sum": "$stock"},
        "total_borrow": {"$sum": "$borrow_count"},
        "avg_price": {"$avg": "$price"},
        "max_price": {"$max": "$price"},
    }},
    {"$project": {"_id": 0, "category": "$_id", "book_count": 1, "total_stock": 1,
                  "total_borrow": 1,
                  "avg_price": {"$round": ["$avg_price", 2]},
                  "max_price": 1,
                  "updated_at": "$$NOW"}},
]
jobs.create_index([("job", 1), ("run_at", DESCENDING)], name="idx_job_run_at")
db["category_stats"].create_index([("category", 1)], unique=True, name="uk_category")
books.aggregate(pipeline_cate + [
    {"$merge": {"into": "category_stats", "on": "category",
                "whenMatched": "replace", "whenNotMatched": "insert"}}])
for d in db["category_stats"].find({}, {"_id": 0}).sort("book_count", DESCENDING):
    print("    %-6s 藏书 %2d 本  库存合计 %3d  借阅合计 %4d 次  均价 %.2f"
          % (d["category"], d["book_count"], d["total_stock"], d["total_borrow"], d["avg_price"]))

# ---------------------------------------------------------------- 2. 借阅统计
print("\n[2] 借阅流水统计（$unwind 展平 + 状态计数）")
pipeline_log = [
    {"$group": {
        "_id": {"card": "$reader_card", "status": "$status"},
        "n": {"$sum": 1},
    }},
    {"$group": {
        "_id": "$_id.card",
        "total": {"$sum": "$n"},
        "detail": {"$push": {"k": "$_id.status", "v": "$n"}},
    }},
    {"$sort": {"total": DESCENDING}},
    {"$limit": 5},
    {"$project": {"_id": 0, "reader": "$_id", "total": 1,
                  "by_status": {"$arrayToObject": "$detail"}}},
]
for d in logs.aggregate(pipeline_log):
    print("    %-10s 共 %d 次  %s" % (d["reader"], d["total"], d["by_status"]))

# ---------------------------------------------------------------- 3. 任务日志
cost = round(time.time() - START, 3)
summary = {
    "job": "nightly_stats",
    "run_at": datetime.datetime.now(),
    "cost_seconds": cost,
    "books": books.count_documents({}),
    "readers": readers.count_documents({}),
    "logs": logs.count_documents({}),
    "status": "success",
}
jobs.insert_one(summary)
print("\n[3] 任务执行日志已写入 platform_jobs 集合：")
print("    耗时 %.3f 秒，处理 books %d 条 / readers %d 条 / borrow_logs %d 条"
      % (cost, summary["books"], summary["readers"], summary["logs"]))

print("\n[4] 最近 3 次任务日志：")
for d in jobs.find({}, {"_id": 0, "job": 1, "run_at": 1,
                        "cost_seconds": 1, "status": 1}).sort("run_at", DESCENDING).limit(3):
    print("    %s  %-14s 耗时 %.3fs  %s"
          % (d["run_at"].strftime("%Y-%m-%d %H:%M:%S"), d["job"], d["cost_seconds"], d["status"]))

client.close()
print("\n[5] 定期统计任务执行结束")
