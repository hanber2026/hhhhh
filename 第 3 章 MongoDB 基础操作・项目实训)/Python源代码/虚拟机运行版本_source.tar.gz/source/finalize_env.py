﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
最终环境收尾 + 证据采集（任务四 ST-4.2 索引清单 / 账号角色 / 权限验证抽检）

1. 删除过程脚本遗留的集合与索引，恢复任务书要求的最终形态
2. 重新贴齐 ST-4.2 六类索引
3. 输出索引清单、特殊集合定义、账号清单与权限验证结果
输出：/root/out_final_env.txt
"""
import json
import io

from pymongo import MongoClient
from pymongo.errors import OperationFailure, DuplicateKeyError

LIB = "mongodb://root:Root%402026@127.0.0.1:27017/?authSource=admin"
ADM = "mongodb://root:Root%402026@127.0.0.1:27017/?authSource=admin"

out = []


def p(*a):
    line = " ".join(str(x) for x in a)
    print(line)
    out.append(line)


def pn(text):
    """不换行输出（等同于 print(..., end=" ")），同时暂存到输出缓冲。"""
    print(text, end=" ")
    out.append(text)


def sec(t):
    p("")
    p("#" * 16 + " " + t + " " + "#" * 16)


client = MongoClient(LIB, serverSelectionTimeoutMS=5000)   # 用 admin 账号做环境收尾（libWriter 无权 listIndexes system.views）
db = client["library"]

sec("0. 清理过程脚本遗留对象")
for name in ("platform_jobs", "books_import", "borrow_logs_import", "r", "x", "t"):
    try:
        db.drop_collection(name)
        p("已确认 %-18s 不存在或已删除" % name)
    except OperationFailure as e:
        p("%-18s 清理失败：%s" % (name, e))
for idx in ("idx_isbn_unique", "idx_title", "idx_category", "idx_tags", "idx_isbn", "uk_isbn_tmp", "idx_category_price_old"):
    try:
        db.books.drop_index(idx)
        p("已删除遗留索引 books.%s" % idx)
    except OperationFailure as e:
        p("books.%s 不存在或已删除（%s）" % (idx, str(e).split(",")[0]))
# 过程脚本插入的演示数据（isbn 以 9787 开头的新增书、operator 标记的流水）不在正式数据中
p("books 文档数 =", db.books.count_documents({}))
p("borrow_logs 文档数 =", db.borrow_logs.count_documents({}))
p("readers 文档数 =", db.readers.count_documents({}))

sec("1. ST-4.2 索引设置（六类索引）")
targets = [
    ("books", "idx_category_price", [("category", 1), ("price", -1)], {}),
    ("books", "idx_text_title_author", [("title", "text"), ("author", "text")], {"default_language": "none"}),
    ("books", "uk_isbn", [("isbn", 1)], {"unique": True}),
    ("books", "idx_borrow_count_desc", [("borrow_count", -1)], {}),
    ("readers", "uk_card_no", [("card_no", 1)], {"unique": True}),
    ("borrow_logs", "idx_card_date", [("reader_card", 1), ("borrow_date", -1)], {}),
]
for coll, name, keys, opt in targets:
    kw = {"name": name}
    kw.update(opt)
    p("命令：db.%s.createIndex(%s, %s)" % (coll, json.dumps(dict(keys), ensure_ascii=False), json.dumps(kw, ensure_ascii=False)))
    try:
        r = db[coll].create_index(keys, **kw)
        p("  返回：", r)
    except OperationFailure as e:
        p("  （已存在，跳过）", str(e).split(",")[0])

sec("2. 索引清单")
for coll in ("books", "readers", "borrow_logs", "category_stats", "book_logs"):
    p("---- %s ----" % coll)
    for idx in db[coll].list_indexes():
        p("  %-26s key=%-42s unique=%s" % (idx["name"], json.dumps(dict(idx["key"]), ensure_ascii=False), idx.get("unique", False)))

sec("3. 三类特殊集合与视图定义")
for info in db.list_collections():
    name = info["name"]
    if name.startswith("system."):
        continue
    p("---- %s ----" % name)
    p("  type =", info.get("type", "collection"))
    opts = info.get("options", {})
    if opts:
        p("  options =", json.dumps({k: str(v) for k, v in opts.items()}, ensure_ascii=False))

sec("4. 唯一索引约束验证")
p("命令：db.books.insertOne({isbn: '9787115428028', ...})   # 与已有图书 ISBN 重复")
try:
    db.books.insert_one({"isbn": "9787115428028", "title": "重复 ISBN 测试"})
    p("  !! 插入成功，唯一索引未生效")
except DuplicateKeyError as e:
    p("  插入被拒绝：code=%s" % e.code)
    p("  %s" % str(e.details.get("errmsg", e)))
p("命令：db.readers.insertOne({card_no: 'R20240001', ...})   # 与已有读者证号重复")
try:
    db.readers.insert_one({"card_no": "R20240001", "name": "重复证号测试"})
    p("  !! 插入成功，唯一索引未生效")
except DuplicateKeyError as e:
    p("  插入被拒绝：code=%s" % e.code)
    p("  %s" % str(e.details.get("errmsg", e)))

sec("5. 账号清单（admin 账号从 admin 库查询）")
adm = MongoClient(ADM, serverSelectionTimeoutMS=5000)
for u in adm["admin"].system.users.find({}, {"user": 1, "db": 1, "roles": 1, "_id": 0}).sort("user", 1):
    p("  %-10s db=%-8s roles=%s" % (u["user"], u["db"], [r["role"] + "@" + r["db"] for r in u["roles"]]))

sec("6. 权限验证抽检")
rd = MongoClient("mongodb://libReader:Reader%402026@127.0.0.1:27017/?authSource=library")
p("---- libReader（read@library）----")
p("  可读 books 文档数 =", rd["library"].books.count_documents({}))
p("  可读视图 book_in_stock 文档数 =", rd["library"].book_in_stock.count_documents({}))
for op, fn in (
    ("insert", lambda: rd["library"].books.insert_one({"isbn": "9787000000001", "title": "只读账号不应写入成功"})),
    ("update", lambda: rd["library"].books.update_one({"isbn": "9787115428028"}, {"$set": {"stock": 99}})),
    ("delete", lambda: rd["library"].books.delete_one({"isbn": "9787115428028"})),
):
    p("  尝试 %-7s ->" % op)
    try:
        fn()
        p("    !! 越权操作成功了（不符合预期）")
    except OperationFailure as e:
        p("    被拒绝：%s" % str(e).split(", full error")[0][:110])

sec("7. 执行计划对比（有索引 vs 全表扫描）")
for kw, label in (
    ({}, "有索引（category + price 复合索引）"),
    ({"hint": {"$natural": 1}}, "强制全表扫描 .hint({$natural:1})"),
):
    ex = db.books.find({"category": "计算机", "price": {"$gt": 80}}, {"_id": 0, "title": 1}).sort({"price": -1}).explain(**kw)
    plan = ex["queryPlanner"]["winningPlan"]
    stage = plan["stage"]
    inner = plan.get("inputStage", {}).get("stage")
    p("---- %s ----" % label)
    p("  执行计划：%s -> %s" % (stage, inner))
    p("  nReturned=%s totalKeysExamined=%s totalDocsExamined=%s"
      % (ex["executionStats"]["nReturned"], ex["executionStats"]["totalKeysExamined"], ex["executionStats"]["totalDocsExamined"]))

sec("8. 最终文档数核对")
counts = {}
for c in ("books", "readers", "borrow_logs", "category_stats", "book_logs", "book_in_stock"):
    counts[c] = db[c].count_documents({})
p(json.dumps(counts, ensure_ascii=False))
p("")
p("环境收尾完成。")

io.open("/root/out_final_env.txt", "w", encoding="utf-8").write("\n".join(out) + "\n")
