#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
最终环境收尾 + 证据采集（ST-4.2 索引清单 / 特殊集合定义 / 账号角色 / 权限验证抽检）

1. 删除过程脚本遗留的集合与索引，恢复任务书要求的最终形态
2. 重新贴齐 ST-4.2 六类索引
3. 输出索引清单、三类特殊集合与视图定义、账号清单、权限验证、执行计划对比
输出：/root/out_final_run.txt
"""
import io
import json

from pymongo import MongoClient
from pymongo.errors import DuplicateKeyError, OperationFailure

ADM_URI = "mongodb://root:Root%402026@127.0.0.1:27017/?authSource=admin"
lib = MongoClient(ADM_URI, serverSelectionTimeoutMS=5000)["library"]
admin = MongoClient(ADM_URI, serverSelectionTimeoutMS=5000)["admin"]

out = []


def p(*a):
    line = " ".join(str(x) for x in a)
    print(line)
    out.append(line)


def sec(t):
    p("")
    p("#" * 16 + " " + t + " " + "#" * 16)


sec("0. 清理过程脚本遗留对象")
for name in ("platform_jobs", "books_import", "borrow_logs_import", "x", "t", "r"):
    lib.drop_collection(name)
p("已清理过程脚本遗留集合（不存在则跳过）：platform_jobs / books_import / borrow_logs_import / x / t / r")
for idx in ("idx_isbn_unique", "idx_title", "idx_category", "idx_tags", "idx_isbn"):
    try:
        lib.books.drop_index(idx)
        p("已删除遗留索引 books.%s" % idx)
    except OperationFailure as e:
        p("books.%s 不存在（%s）" % (idx, str(e).split(",")[0]))
p("books 文档数 =", lib.books.count_documents({}))
p("readers 文档数 =", lib.readers.count_documents({}))
p("borrow_logs 文档数 =", lib.borrow_logs.count_documents({}))

sec("1. ST-4.2 索引设置（六类索引）")
targets = [
    ("books", "idx_category_price", [("category", 1), ("price", -1)], {}, "复合索引：分类 + 价格降序"),
    ("books", "idx_text_title_author", [("title", "text"), ("author", "text")], {"default_language": "none"}, "文本索引：书名 + 作者"),
    ("books", "uk_isbn", [("isbn", 1)], {"unique": True}, "唯一索引：防止 ISBN 重复录入"),
    ("books", "idx_borrow_count_desc", [("borrow_count", -1)], {}, "单字段降序索引：借阅热度排序"),
    ("readers", "uk_card_no", [("card_no", 1)], {"unique": True}, "唯一索引：读者证号"),
    ("borrow_logs", "idx_card_date", [("reader_card", 1), ("borrow_date", -1)], {}, "复合索引：读者 + 借阅时间"),
]
for coll, name, keys, opt, memo in targets:
    kw = {"name": name}
    kw.update(opt)
    p("命令：db.%s.createIndex(%s, %s)   # %s"
      % (coll, json.dumps(dict(keys), ensure_ascii=False), json.dumps(kw, ensure_ascii=False), memo))
    try:
        p("  返回：%s" % lib[coll].create_index(keys, **kw))
    except OperationFailure as e:
        p("  已存在，跳过（%s）" % str(e).split(",")[0])

sec("2. 索引清单")
for coll in ("books", "readers", "borrow_logs", "category_stats", "book_logs"):
    p("---- %s ----" % coll)
    for idx in lib[coll].list_indexes():
        p("  %-26s key=%-44s unique=%s" % (idx["name"], json.dumps(dict(idx["key"]), ensure_ascii=False), idx.get("unique", False)))

sec("3. 三类特殊集合与视图定义")
for info in lib.list_collections():
    name = info["name"]
    if name.startswith("system."):
        continue
    p("---- %s ----" % name)
    p("  type = %s" % info.get("type", "collection"))
    opts = info.get("options", {})
    if opts:
        p("  options = %s" % json.dumps({k: str(v) for k, v in opts.items()}, ensure_ascii=False))

sec("4. 唯一索引约束验证")
p("命令：db.books.insertOne({isbn: '9787115428028', ...})   # 与已有图书 ISBN 重复")
try:
    lib.books.insert_one({"isbn": "9787115428028", "title": "重复 ISBN 测试"})
    p("  !! 插入成功，唯一索引未生效")
except DuplicateKeyError as e:
    p("  插入被拒绝：code=%s" % e.code)
    p("  %s" % e.details.get("errmsg", str(e)))
p("命令：db.readers.insertOne({card_no: 'R20240001', ...})   # 与已有读者证号重复")
try:
    lib.readers.insert_one({"card_no": "R20240001", "name": "重复证号测试"})
    p("  !! 插入成功，唯一索引未生效")
except DuplicateKeyError as e:
    p("  插入被拒绝：code=%s" % e.code)
    p("  %s" % e.details.get("errmsg", str(e)))

sec("5. 账号清单")
for u in admin.system.users.find({}, {"user": 1, "db": 1, "roles": 1, "_id": 0}).sort("user", 1):
    p("  %-10s db=%-8s roles=%s" % (u["user"], u["db"], [r["role"] + "@" + r["db"] for r in u["roles"]]))

sec("6. 权限验证抽检")
rd = MongoClient("mongodb://libReader:Reader%402026@127.0.0.1:27017/?authSource=library", serverSelectionTimeoutMS=5000)
p("---- libReader（read@library）----")
p("  可读 books 文档数 = %s" % rd["library"].books.count_documents({}))
p("  可读视图 book_in_stock 文档数 = %s" % rd["library"].book_in_stock.count_documents({}))
for op, fn in (
    ("insert", lambda: rd["library"].books.insert_one({"isbn": "9787000000001", "title": "只读账号不应写入成功"})),
    ("update", lambda: rd["library"].books.update_one({"isbn": "9787115428028"}, {"$set": {"stock": 99}})),
    ("delete", lambda: rd["library"].books.delete_one({"isbn": "9787115428028"})),
    ("dropDatabase", lambda: rd["library"].client.drop_database("library")),
):
    try:
        fn()
        p("  尝试 %-12s -> !! 越权操作成功了（不符合预期）" % op)
    except OperationFailure as e:
        p("  尝试 %-12s -> 被拒绝：%s" % (op, str(e).split(", full error")[0][:100]))

sec("7. 执行计划对比（有索引 vs 全表扫描）")
Q = {"category": "计算机", "price": {"$gt": 80}}
for label, hint in (("有索引（走 idx_category_price）", None), ("强制全表扫描 .hint({$natural:1})", {"$natural": 1})):
    cur = lib.books.find(Q, {"_id": 0, "title": 1}).sort({"price": -1})
    if hint:
        cur = cur.hint(hint)
    ex = cur.explain()
    plan = ex["queryPlanner"]["winningPlan"]
    stages = []
    idxname = "无"
    node = plan
    while node:
        stages.append(node.get("stage"))
        if node.get("indexName"):
            idxname = node["indexName"]
        node = node.get("inputStage")
    st = ex["executionStats"]
    p("---- %s ----" % label)
    p("  执行计划：%s   （索引：%s）" % (" -> ".join(s for s in stages if s), idxname))
    p("  nReturned=%s  totalKeysExamined=%s  totalDocsExamined=%s  executionTimeMillis=%s"
      % (st["nReturned"], st["totalKeysExamined"], st["totalDocsExamined"], st["executionTimeMillis"]))

sec("8. 最终文档数核对")
counts = {}
for c in ("books", "readers", "borrow_logs", "category_stats", "book_logs", "book_in_stock"):
    counts[c] = lib[c].count_documents({})
p(json.dumps(counts, ensure_ascii=False))
p("")
p("环境收尾完成。")

io.open("/root/out_final_run.txt", "w", encoding="utf-8").write("\n".join(out) + "\n")
