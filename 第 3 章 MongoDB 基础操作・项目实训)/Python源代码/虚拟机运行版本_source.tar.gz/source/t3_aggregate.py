#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ST-5.3  图书情报检索与统计平台 —— 聚合统计（PyMongo Aggregate）
文件：t3_aggregate.py
运行：python3 t3_aggregate.py
说明：把任务四中用 mongosh 编写的聚合管道改写成 PyMongo 版本，覆盖
      $match / $group / $sort / $lookup / $unwind / $project / $addFields / $facet，
      包含分类统计、出版社 Top5、读者借阅排行、分类-学院交叉分析、月度趋势与 $facet 多面统计。
"""
import pymongo
from urllib.parse import quote_plus
from pymongo import MongoClient, DESCENDING, ASCENDING

URI = ("mongodb://libWriter:%s@127.0.0.1:27017/?authSource=library" % quote_plus("Writer@2026"))
client = MongoClient(URI, serverSelectionTimeoutMS=5000)
db = client["library"]
books, readers, logs = db["books"], db["readers"], db["borrow_logs"]

print("=" * 72)
print(" ST-5.3  聚合统计    (PyMongo %s)" % pymongo.version)
print("=" * 72)


def head(n):
    print("\n" + "-" * 72)
    print("[%d] %s" % (n, _title))


# ---------------------------------------------------------------- A1 分类统计
_title = "分类维度统计：数量、均价、均分、库存"
pipeline1 = [
    {"$group": {
        "_id": "$category",
        "book_count": {"$sum": 1},
        "avg_price": {"$avg": "$price"},
        "avg_rating": {"$avg": "$rating"},
        "total_stock": {"$sum": "$stock"},
    }},
    {"$project": {
        "_id": 0, "category": "$_id",
        "book_count": 1,
        "avg_price": {"$round": ["$avg_price", 2]},
        "avg_rating": {"$round": ["$avg_rating", 2]},
        "total_stock": 1,
    }},
    {"$sort": {"book_count": DESCENDING}},
]
head(1)
print("    " + _title)
print("    %-8s %4s %8s %6s %6s" % ("分类", "数量", "均价", "均分", "库存"))
for d in books.aggregate(pipeline1):
    print("    %-8s %4d %8.2f %6.2f %6d" % (d["category"], d["book_count"],
                                           d["avg_price"], d["avg_rating"], d["total_stock"]))

# ---------------------------------------------------------------- A2 出版社 Top5
_title = "出版社 Top5（按藏书量）"
pipeline2 = [
    {"$group": {"_id": "$publisher", "count": {"$sum": 1}, "avg_price": {"$avg": "$price"}}},
    {"$sort": {"count": DESCENDING, "_id": ASCENDING}},
    {"$limit": 5},
    {"$project": {"_id": 0, "publisher": "$_id", "count": 1, "avg_price": {"$round": ["$avg_price", 2]}}},
]
head(2)
print("    " + _title)
for i, d in enumerate(books.aggregate(pipeline2), 1):
    print("    %d. %-16s %2d 本   均价 %.2f" % (i, d["publisher"], d["count"], d["avg_price"]))

# ---------------------------------------------------------------- A3 借阅次数排行
_title = "图书借阅热度排行 Top5（$addFields 计算热度）"
pipeline3 = [
    {"$addFields": {"heat": {"$multiply": ["$borrow_count", "$rating"]}}},
    {"$sort": {"borrow_count": DESCENDING, "rating": DESCENDING}},
    {"$limit": 5},
    {"$project": {"_id": 0, "title": 1, "borrow_count": 1, "rating": 1, "heat": {"$round": ["$heat", 2]}}},
]
head(3)
print("    " + _title)
for i, d in enumerate(books.aggregate(pipeline3), 1):
    print("    %d. %-30s 借阅 %2d 次  评分 %.1f  热度 %.2f"
          % (i, d["title"], d["borrow_count"], d["rating"], d["heat"]))

# ---------------------------------------------------------------- A4 读者借阅排行
_title = "读者借阅排行（$lookup 关联 readers + 姓名脱敏）"
pipeline4 = [
    {"$group": {"_id": "$reader_card", "times": {"$sum": 1},
                "first": {"$min": "$borrow_date"}, "last": {"$max": "$borrow_date"}}},
    {"$lookup": {"from": "readers", "localField": "_id", "foreignField": "card_no", "as": "r"}},
    {"$unwind": "$r"},
    {"$sort": {"times": DESCENDING, "_id": ASCENDING}},
    {"$limit": 8},
    {"$project": {
        "_id": 0,
        "card_no": "$_id",
        "name": {"$concat": [
            {"$substrCP": ["$r.name", 0, 1]}, "**",
        ]},
        "college": "$r.college", "level": "$r.level",
        "times": 1,
        "span": {"$dateToString": {"format": "%Y-%m-%d", "date": "$first"}},
    }},
]
head(4)
print("    " + _title)
for i, d in enumerate(logs.aggregate(pipeline4), 1):
    print("    %d. %-10s %-4s %-12s %-4s %d 次  首次借阅 %s"
          % (i, d["card_no"], d["name"], d["college"], d["level"], d["times"], d["span"]))

# ---------------------------------------------------------------- A5 分类×学院
_title = "分类 × 学院 交叉统计（$lookup 图书 + $group）"
pipeline5 = [
    {"$lookup": {"from": "books", "localField": "book_isbn", "foreignField": "isbn", "as": "b"}},
    {"$unwind": "$b"},
    {"$lookup": {"from": "readers", "localField": "reader_card", "foreignField": "card_no", "as": "r"}},
    {"$unwind": "$r"},
    {"$group": {"_id": {"cate": "$b.category", "college": "$r.college"}, "n": {"$sum": 1}}},
    {"$group": {"_id": "$_id.cate",
                "total": {"$sum": "$n"},
                "detail": {"$push": {"k": "$_id.college", "v": "$n"}}}},
    {"$sort": {"total": DESCENDING}},
    {"$project": {"_id": 0, "category": "$_id", "total": 1,
                  "by_college": {"$arrayToObject": "$detail"}}},
]
head(5)
print("    " + _title)
for d in logs.aggregate(pipeline5):
    detail = "、".join("%s:%d" % (k, v) for k, v in d["by_college"].items())
    print("    %-6s 合计 %2d —— %s" % (d["category"], d["total"], detail))

# ---------------------------------------------------------------- A6 月度趋势
_title = "借阅月度趋势（$dateToString 按年月分组）"
pipeline6 = [
    {"$group": {
        "_id": {"$dateToString": {"format": "%Y-%m", "date": "$borrow_date"}},
        "times": {"$sum": 1},
        "overdue": {"$sum": {"$cond": [{"$eq": ["$status", "逾期"]}, 1, 0]}},
    }},
    {"$sort": {"_id": ASCENDING}},
    {"$project": {"_id": 0, "month": "$_id", "times": 1, "overdue": 1,
                  "rate": {"$round": [{"$divide": [{"$multiply": ["$overdue", 100]}, "$times"]}, 1]}}},
]
head(6)
print("    " + _title)
print("    %-8s %4s %4s %8s" % ("月份", "次数", "逾期", "逾期率%"))
for d in logs.aggregate(pipeline6):
    bar = "#" * d["times"]
    print("    %-8s %4d %4d %7.1f  %s" % (d["month"], d["times"], d["overdue"], d["rate"], bar))

# ---------------------------------------------------------------- A7 $facet
_title = "$facet 多面统计：一次管道返回四组结果"
pipeline7 = [
    {"$facet": {
        "by_status": [{"$group": {"_id": "$status", "n": {"$sum": 1}}}, {"$sort": {"n": DESCENDING}}],
        "top_books": [{"$group": {"_id": "$book_isbn", "n": {"$sum": 1}}},
                      {"$sort": {"n": DESCENDING}}, {"$limit": 3}],
        "top_readers": [{"$group": {"_id": "$reader_card", "n": {"$sum": 1}}},
                        {"$sort": {"n": DESCENDING}}, {"$limit": 3}],
        "summary": [{"$group": {"_id": None, "total": {"$sum": 1},
                                "distinct_books": {"$addToSet": "$book_isbn"},
                                "distinct_readers": {"$addToSet": "$reader_card"}}},
                    {"$project": {"_id": 0, "total": 1,
                                  "book_kinds": {"$size": "$distinct_books"},
                                  "reader_kinds": {"$size": "$distinct_readers"}}}],
    }}
]
head(7)
print("    " + _title)
res = list(logs.aggregate(pipeline7))[0]
print("    借阅状态分布 : %s" % "、".join("%s %d 次" % (x["_id"], x["n"]) for x in res["by_status"]))
print("    借阅最多图书 : %s" % "、".join("%s(%d 次)" % (x["_id"], x["n"]) for x in res["top_books"]))
print("    借阅最多读者 : %s" % "、".join("%s(%d 次)" % (x["_id"], x["n"]) for x in res["top_readers"]))
s = res["summary"][0]
print("    总体概况     : 共 %d 条借阅记录，涉及 %d 种图书、%d 位读者"
      % (s["total"], s["book_kinds"], s["reader_kinds"]))

# ---------------------------------------------------------------- A8 写回分类统计表
_title = "统计结果写回 category_stats 集合（$merge）"
pipeline8 = [
    {"$group": {"_id": "$category", "book_count": {"$sum": 1},
                "total_borrow": {"$sum": "$borrow_count"},
                "avg_price": {"$avg": "$price"}}},
    {"$project": {"_id": 0, "category": "$_id", "book_count": 1, "total_borrow": 1,
                  "avg_price": {"$round": ["$avg_price", 2]},
                  "updated_at": "$$NOW"}},
    # 说明：$merge 的 on 字段必须是“唯一索引”，否则服务端报
    #   Cannot find index to verify that join fields will be unique (code 51183)
    # 因此先为统计表建立 category 唯一索引，再执行 $merge。
]
head(8)
db["category_stats"].create_index([("category", 1)], unique=True, name="uk_category")
print("    为 category_stats 建立唯一索引 uk_category（$merge on 字段的唯一性前提）")
books.aggregate(pipeline8)
print("    " + _title)
print("    category_stats 当前内容：")
for d in db["category_stats"].find({}, {"_id": 0}).sort("book_count", DESCENDING):
    print("      %-6s 藏书 %2d 本  借阅合计 %3d 次  均价 %.2f  更新于 %s"
          % (d["category"], d["book_count"], d["total_borrow"], d["avg_price"],
             d["updated_at"].strftime("%Y-%m-%d %H:%M:%S")))

client.close()
print("\n[9] 全部聚合统计完成，程序正常结束")
