#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ST-5.2  图书情报检索与统计平台 —— 条件检索与分页
文件：t2_search_paging.py
运行：python3 t2_search_paging.py
说明：演示多条件组合查询（逻辑运算、比较运算、正则、数组、嵌套字段）、
      结果排序、字段投影，以及 skip/limit 方式与游标方式两种分页实现。
"""
import pymongo
from urllib.parse import quote_plus
from pymongo import MongoClient, ASCENDING, DESCENDING

URI = ("mongodb://libWriter:%s@127.0.0.1:27017/?authSource=library" % quote_plus("Writer@2026"))
PAGE_SIZE = 5

client = MongoClient(URI, serverSelectionTimeoutMS=5000)
db = client["library"]
books = db["books"]

print("=" * 72)
print(" ST-5.2  条件检索与分页    (PyMongo %s)" % pymongo.version)
print("=" * 72)


# ---------------------------------------------------------------- 工具函数
def show(title, cursor, fields=("title", "author", "category", "price")):
    """打印一个查询的结果集。"""
    docs = list(cursor)
    print("\n%s   —— 命中 %d 条" % (title, len(docs)))
    line = "   " + "".join("%-4s" % "" for _ in range(0))
    for i, d in enumerate(docs, 1):
        vals = []
        for f in fields:
            v = d.get(f, "-")
            if isinstance(v, float):
                v = "%.2f" % v
            vals.append(str(v))
        print("   %2d. %-34s | %-12s | %-6s | %s" % (i, vals[0][:34], vals[1][:12], vals[2][:6], vals[3]))
    return docs


# ---------------------------------------------------------------- 1. 比较运算
print("\n[1] 比较运算：价格 >= 80 元的图书")
c = books.find({"price": {"$gte": 80}}, {"_id": 0, "title": 1, "author": 1, "category": 1, "price": 1}) \
         .sort("price", DESCENDING)
show("价格 >= 80", c)

print("\n    等价 SQL：SELECT title,author,category,price FROM books WHERE price >= 80 ORDER BY price DESC")

# ---------------------------------------------------------------- 2. 逻辑组合
print("\n[2] 逻辑组合：($and / $or / $in / $nin)")
q = {
    "$and": [
        {"category": {"$in": ["计算机", "数学"]}},
        {"$or": [{"price": {"$lt": 70}}, {"rating": {"$gte": 4.7}}]},
        {"publisher": {"$nin": ["机械工业出版社"]}},
        {"stock": {"$gt": 0}},
    ]
}
c = books.find(q, {"_id": 0, "title": 1, "author": 1, "category": 1, "price": 1}).sort([("category", ASCENDING), ("price", DESCENDING)])
show("计算机/数学 且（价格<70 或 评分>=4.7）且 非机械工业 且 有库存", c)

# ---------------------------------------------------------------- 3. 正则匹配
print("\n[3] 正则匹配：标题包含“数据”或“Python”")
c = books.find({"title": {"$regex": "数据|Python"}}, {"_id": 0, "title": 1, "author": 1, "category": 1, "price": 1})
show("title =~ /数据|Python/", c, ("title", "author", "category", "price"))

# ---------------------------------------------------------------- 4. 数组查询
print("\n[4] 数组查询：tags 包含“编程”")
c = books.find({"tags": "编程"}, {"_id": 0, "title": 1, "author": 1, "category": 1, "tags": 1})
docs = list(c)
print("    命中 %d 条" % len(docs))
for i, d in enumerate(docs, 1):
    print("   %2d. %-32s tags=%s" % (i, d["title"], d.get("tags")))

print("\n    $all：tags 同时包含 编程 与 入门")
for d in books.find({"tags": {"$all": ["编程", "入门"]}}, {"_id": 0, "title": 1, "tags": 1}):
    print("      %s  tags=%s" % (d["title"], d.get("tags")))

print("\n    $size：tags 恰好 3 个")
n = books.count_documents({"tags": {"$size": 3}})
print("      命中 %d 条" % n)

# ---------------------------------------------------------------- 5. 存在性与空值
print("\n[5] 存在性判断：publish_date 存在 / email 为 null")
print("    books 中 publish_date 存在 : %d 条" % books.count_documents({"publish_date": {"$exists": True}}))
print("    books 中 tags 字段缺失     : %d 条" % books.count_documents({"tags": {"$exists": False}}))
print("    readers 中 email 为 null   : %d 人" % db["readers"].count_documents({"email": None}))

# ---------------------------------------------------------------- 6. 分页（skip/limit）
print("\n" + "-" * 72)
print("[6] 分页实现方式一：skip + limit")
cond = {"stock": {"$gt": 0}}
total = books.count_documents(cond)
pages = (total + PAGE_SIZE - 1) // PAGE_SIZE
print("    条件 stock>0 共 %d 条，每页 %d 条，共 %d 页" % (total, PAGE_SIZE, pages))
for p in range(1, pages + 1):
    cur = books.find(cond, {"_id": 0, "title": 1, "stock": 1}) \
               .sort("borrow_count", DESCENDING).skip((p - 1) * PAGE_SIZE).limit(PAGE_SIZE)
    titles = [x["title"][:12] for x in cur]
    print("    第 %d 页（skip=%2d limit=%d）: %s" % (p, (p - 1) * PAGE_SIZE, PAGE_SIZE, "、".join(titles)))

# ---------------------------------------------------------------- 7. 分页（游标）
print("\n[7] 分页实现方式二：基于上一页最后一条记录的 _id / 排序键游标（避免深分页 skip 开销）")
last_price, last_id = None, None
for p in range(1, 4):
    cond2 = {"stock": {"$gt": 0}}
    if last_price is not None:
        cond2 = {"$and": [cond2, {"$or": [
            {"price": {"$lt": last_price}},
            {"price": last_price, "_id": {"$gt": last_id}},
        ]}]}
    docs = list(books.find(cond2, {"_id": 1, "title": 1, "price": 1})
                .sort([("price", DESCENDING), ("_id", ASCENDING)]).limit(PAGE_SIZE))
    if not docs:
        print("    第 %d 页: 无数据" % p)
        break
    print("    第 %d 页: %s" % (p, "、".join("%s(%.1f)" % (d["title"][:10], d["price"]) for d in docs)))
    last_price, last_id = docs[-1]["price"], docs[-1]["_id"]

# ---------------------------------------------------------------- 8. 使用 hint 的检索
print("\n[8] 检索计划验证：使用 hint('idx_category_price')")
explain = db.command("explain", {
    "find": "books",
    "filter": {"category": "计算机", "price": {"$gt": 80}},
    "hint": "idx_category_price",
})
stage = explain["queryPlanner"]["winningPlan"]
used = []


def walk(plan):
    for k in ("stage", "indexName"):
        if k in plan:
            used.append("%s=%s" % (k, plan[k]))
    for v in plan.values():
        if isinstance(v, dict):
            walk(v)
        elif isinstance(v, list):
            for x in v:
                if isinstance(x, dict):
                    walk(x)


walk(stage)
print("    执行计划节点: %s" % ", ".join(used))

client.close()
print("\n[9] 程序正常结束")
