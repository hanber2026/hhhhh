#!/usr/bin/env bash
# ============================================================
# 任务五 · 图书情报检索与统计平台 —— 菜单式主程序演示（自动喂入菜单输入）
# 运行： bash run_main.sh
# ============================================================
cd /root/source || exit 1
export LANG=C.UTF-8 LC_ALL=C.UTF-8
cat <<'INPUT' | python3 main.py
9
4
数据结构
1
1
10
2
3
5
2
4
5
6
7
8
0
INPUT
echo "### exit code = $?"
