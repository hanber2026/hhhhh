#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ST-5.5  图书情报检索与统计平台 —— 综合平台（菜单交互 + 一条龙演示）
文件：t5_platform.py
运行：python3 t5_platform.py           交互式菜单（推荐在终端里运行，可手工选择功能）
      python3 t5_platform.py --demo    自动依次执行全部功能（用于批量出结果、录屏）
功能：1 新增图书  2 关键字检索（分页）  3 借阅登记  4 归还登记
      5 分类统计  6 读者借阅排行  7 逾期提醒  8 今日概览
"""
import sys
from urllib.parse import quote_plus
import datetime
import pymongo
from pymongo import MongoClient, DESCENDING

URI = ("mongodb://libWriter:%s@127.0.0.1:27017/?authSource=library" % quote_plus("Writer@2026"))
client = MongoClient(URI, serverSelectionTimeoutMS=5000)
db = client["library"]
books, readers, logs = db["books"], db["readers"], db["borrow_logs"]
TODAY = datetime.datetime.now()

LINE = "-" * 72


def title(text):
    print("\n" + LINE)
    print("  " + text)
    print(LINE)


def pause(demo):
    if not demo:
        input("  按回车键继续……")


# ---------------------------------------------------------------- 功能实现
def f_add_book():
    """新增图书：演示 insert_one + 唯一索引冲突处理。"""
    title("功能 1：新增图书（演示数据入库）")
    doc = {
        "isbn": "9787000000010",
        "title": "MongoDB 数据库技术与应用",
        "author": "图书情报实训组",
        "publisher": "计算机学院出版社",
        "category": "计算机",
        "price": 96.0,
        "stock": 5,
        "rating": 4.5,
        "tags": ["数据库", "NoSQL", "教材"],
        "publish_date": datetime.datetime(2023, 9, 1),
        "borrow_count": 0,
        "created_at": TODAY,
    }
    try:
        r = books.insert_one(doc)
        print("  新增成功：%s —— %s，库存 %d 本" % (doc["isbn"], doc["title"], doc["stock"]))
        print("  inserted_id = %s" % r.inserted_id)
    except pymongo.errors.DuplicateKeyError as e:
        print("  该书已存在（唯一索引 idx_isbn_unique 生效），继续使用原记录")
        print("  错误码 %d : %s" % (e.code, str(e)[:70] + " ..."))
    print("  当前藏书总数：%d 本" % books.count_documents({}))


def f_search(keyword="数据", page=1, size=3):
    """关键字检索：多字段模糊匹配 + 分页。"""
    title("功能 2：关键字检索“%s”（每页 %d 条，第 %d 页）" % (keyword, size, page))
    cond = {"$or": [
        {"title": {"$regex": keyword, "$options": "i"}},
        {"author": {"$regex": keyword, "$options": "i"}},
        {"publisher": {"$regex": keyword, "$options": "i"}},
        {"tags": {"$regex": keyword, "$options": "i"}},
    ]}
    total = books.count_documents(cond)
    print("  命中 %d 条，共 %d 页" % (total, (total + size - 1) // size))
    cur = books.find(cond, {"_id": 0, "isbn": 1, "title": 1, "author": 1, "stock": 1, "price": 1}) \
               .sort("borrow_count", DESCENDING).skip((page - 1) * size).limit(size)
    for i, d in enumerate(cur, 1):
        state = "可借 %d 本" % d["stock"] if d["stock"] > 0 else "已全部借出"
        print("   %d. %-30s %-10s %6.2f 元  %s" % (i, d["title"][:30], d["author"][:10], d["price"], state))


def f_borrow(card="R20240003", isbn="9787115428028"):
    """借阅登记：库存校验 + 库存自减 + 借阅记录写入（模拟事务一致性）。"""
    title("功能 3：借阅登记  读者 %s 借 图书 %s" % (card, isbn))
    r = readers.find_one({"card_no": card})
    b = books.find_one({"isbn": isbn})
    if not r or not b:
        print("  读者或图书不存在，借阅失败")
        return
    print("  读者：%s（%s，%s）  图书：%s  当前库存 %d" % (r["name"], r["college"], r["level"], b["title"], b["stock"]))
    upd = books.update_one({"isbn": isbn, "stock": {"$gt": 0}}, {"$inc": {"stock": -1, "borrow_count": 1}})
    if upd.modified_count == 0:
        print("  库存不足，借阅失败")
        return
    doc = {"reader_card": card, "book_isbn": isbn, "borrow_date": TODAY,
           "status": "借出", "operator": "t5_platform.py"}
    logs.insert_one(doc)
    b2 = books.find_one({"isbn": isbn}, {"stock": 1, "borrow_count": 1})
    print("  借阅成功：借阅日期 %s  借期 30 天，应还日期 %s"
          % (TODAY.strftime("%Y-%m-%d"), (TODAY + datetime.timedelta(days=30)).strftime("%Y-%m-%d")))
    print("  库存 %d -> %d，累计借阅 %d 次" % (b["stock"], b2["stock"], b2["borrow_count"]))


def f_return(card="R20240003", isbn="9787115428028"):
    """归还登记：补写归还记录 + 状态改为已归还、库存回补。

    重要限制（时间序列集合）：borrow_logs 以 borrow_date 为 timeField、reader_card 为
    metaField。MongoDB 对时间序列集合的更新有两道“墙”：
      ① 不能用 _id 定位：Cannot perform a non-multi update on a time-series collection；
      ② 更新非 metaField 的字段直接禁止：Cannot perform an update on a time-series
         collection which updates a field that is not the metaField 'reader_card'。
    也就是说 return_date/status 这类普通字段在时间序列集合里“不能原地更新”。
    平台因此采用“追加式”写法：插入一条元数据相同（同一 reader_card、同一 borrow_date）
    的新状态记录，读取时以最新记录为准，这既符合时间序列“只追加”的存储特点，
    也保留了完整的变更历史（审计友好）。
    """
    title("功能 4：归还登记  读者 %s 归还 图书 %s" % (card, isbn))
    rec = logs.find_one({"reader_card": card, "book_isbn": isbn, "status": "借出"},
                        sort=[("borrow_date", DESCENDING)])
    if not rec:
        print("  未找到在借记录，归还失败")
        return
    days = (TODAY - rec["borrow_date"]).days
    before = logs.count_documents({"reader_card": card})
    logs.insert_one({
        "reader_card": card, "book_isbn": isbn,
        "borrow_date": rec["borrow_date"],          # 保持 timeField 不变，归属同一借阅期
        "return_date": TODAY, "status": "已归还",
        "operator": "t5_platform.py",
    })
    books.update_one({"isbn": isbn}, {"$inc": {"stock": 1}})
    st = books.find_one({"isbn": isbn}, {"stock": 1, "borrow_count": 1})
    print("  借阅日期 %s，实际借阅 %d 天" % (rec["borrow_date"].strftime("%Y-%m-%d"), days))
    print("  归还成功：追加归还状态记录 1 条（%s 条 -> %s 条）"
          % (before, logs.count_documents({"reader_card": card})))
    print("  状态 借出 -> 已归还，库存已回补，当前库存 %d 本" % st["stock"])
    print("  该读者最近 3 条借阅流水：")
    for d in logs.find({"reader_card": card},
                       {"_id": 0, "book_isbn": 1, "borrow_date": 1, "return_date": 1, "status": 1}) \
                  .sort("borrow_date", DESCENDING).limit(3):
        print("     %s  借 %s  %s" % (d["borrow_date"].strftime("%Y-%m-%d"),
                                      d.get("book_isbn"), d["status"]))


def f_category_stats():
    """分类统计：聚合管道输出数量、均价、平均评分、借阅热度。"""
    title("功能 5：分类统计")
    pipeline = [
        {"$group": {"_id": "$category", "n": {"$sum": 1}, "avg_price": {"$avg": "$price"},
                    "avg_rating": {"$avg": "$rating"}, "borrow": {"$sum": "$borrow_count"}}},
        {"$sort": {"n": DESCENDING}},
        {"$project": {"_id": 0, "category": "$_id", "n": 1, "borrow": 1,
                      "avg_price": {"$round": ["$avg_price", 2]},
                      "avg_rating": {"$round": ["$avg_rating", 2]}}},
    ]
    print("  %-8s %4s %6s %6s %6s" % ("分类", "藏书", "均价", "均分", "借阅"))
    for d in books.aggregate(pipeline):
        print("  %-8s %4d %6.2f %6.2f %6d" % (d["category"], d["n"], d["avg_price"], d["avg_rating"], d["borrow"]))


def f_reader_rank():
    """读者借阅排行：$lookup 关联借阅记录与读者。"""
    title("功能 6：读者借阅排行 Top5")
    pipeline = [
        {"$group": {"_id": "$reader_card", "n": {"$sum": 1}}},
        {"$lookup": {"from": "readers", "localField": "_id", "foreignField": "card_no", "as": "r"}},
        {"$unwind": "$r"},
        {"$sort": {"n": DESCENDING, "_id": 1}},
        {"$limit": 5},
        {"$project": {"_id": 0, "card": "$_id", "name": "$r.name", "college": "$r.college",
                      "level": "$r.level", "n": 1}},
    ]
    for i, d in enumerate(logs.aggregate(pipeline), 1):
        print("  %d. %-10s %-4s %-14s %-3s %2d 次" % (i, d["card"], d["name"], d["college"], d["level"], d["n"]))


def f_overdue():
    """逾期提醒：借出且超过 30 天未还，或状态为逾期。"""
    title("功能 7：逾期提醒（借期 30 天）")
    limit_date = TODAY - datetime.timedelta(days=30)
    pipeline = [
        {"$match": {"status": {"$in": ["借出", "逾期"]}}},
        {"$lookup": {"from": "books", "localField": "book_isbn", "foreignField": "isbn", "as": "b"}},
        {"$unwind": "$b"},
        {"$lookup": {"from": "readers", "localField": "reader_card", "foreignField": "card_no", "as": "r"}},
        {"$unwind": "$r"},
        {"$addFields": {"days": {"$dateDiff": {"startDate": "$borrow_date", "endDate": "$$NOW", "unit": "day"}}}},
        {"$match": {"$or": [{"days": {"$gt": 30}}, {"status": "逾期"}]}},
        {"$sort": {"days": DESCENDING}},
        {"$project": {"_id": 0, "card": "$reader_card", "reader": "$r.name",
                      "title": "$b.title", "borrow_date": 1, "days": 1, "status": 1}},
    ]
    docs = list(logs.aggregate(pipeline))
    print("  需提醒的记录 %d 条：" % len(docs))
    for i, d in enumerate(docs[:10], 1):
        print("  %d. %-10s %-4s %-24s 借于 %s 已 %d 天 [%s]"
              % (i, d["card"], d["reader"], d["title"][:24],
                 d["borrow_date"].strftime("%Y-%m-%d"), d["days"], d["status"]))


def f_overview():
    """今日概览：各集合规模与关键指标。"""
    title("功能 8：平台今日概览  %s" % TODAY.strftime("%Y-%m-%d %H:%M"))
    total = books.count_documents({})
    avail = books.count_documents({"stock": {"$gt": 0}})
    nomail = readers.count_documents({"email": None})
    st = {d["_id"]: d["n"] for d in logs.aggregate([{"$group": {"_id": "$status", "n": {"$sum": 1}}}])}
    print("  图书总量：%3d 种，其中有库存 %d 种（%.1f%%）" % (total, avail, avail * 100.0 / total))
    print("  读者总量：%3d 人，其中未登记邮箱 %d 人" % (readers.count_documents({}), nomail))
    print("  借阅记录：%3d 条 —— %s" % (logs.count_documents({}),
                                  "、".join("%s %d" % (k, v) for k, v in sorted(st.items(), key=lambda x: -x[1]))))
    top = books.find({}, {"_id": 0, "title": 1, "borrow_count": 1}).sort("borrow_count", DESCENDING).limit(1)
    for d in top:
        print("  借阅冠军：《%s》共 %d 次" % (d["title"], d["borrow_count"]))
    print("  集合对象：%s" % ", ".join(sorted(db.list_collection_names())))


# ---------------------------------------------------------------- 主程序
def main():
    demo = "--demo" in sys.argv
    print("=" * 72)
    print("   图书情报检索与统计平台  v1.0   (PyMongo %s)" % pymongo.version)
    print("   数据库 %s  @ 127.0.0.1:27017    当前时间 %s" % (DB_NAME_STR, TODAY.strftime("%Y-%m-%d %H:%M:%S")))
    print("=" * 72)
    if demo:
        f_add_book(); f_search("数据", 1, 3)
        f_search("人民邮电", 1, 2)
        f_borrow(); f_return()
        f_category_stats(); f_reader_rank(); f_overdue(); f_overview()
        print("\n[演示结束] 全流程功能验证通过。")
        return
    menu = ("\n  1 新增图书   2 关键字检索   3 借阅登记   4 归还登记\n"
            "  5 分类统计   6 读者借阅排行 7 逾期提醒   8 今日概览   0 退出")
    while True:
        print(menu)
        ch = input("  请选择功能编号：").strip()
        if ch == "1":
            f_add_book()
        elif ch == "2":
            kw = input("  检索关键字：").strip() or "数据"
            pg = input("  页码(默认1)：").strip()
            f_search(kw, int(pg) if pg.isdigit() else 1, 3)
        elif ch == "3":
            f_borrow()
        elif ch == "4":
            f_return()
        elif ch == "5":
            f_category_stats()
        elif ch == "6":
            f_reader_rank()
        elif ch == "7":
            f_overdue()
        elif ch == "8":
            f_overview()
        elif ch in ("0", "q"):
            print("  已退出，再见。")
            break
        else:
            print("  无效的选择，请重新输入。")


DB_NAME_STR = DB_NAME = "library"

if __name__ == "__main__":
    try:
        main()
    finally:
        client.close()
