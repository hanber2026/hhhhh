#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
集合校验规则演示（books 的 $jsonSchema 模式验证）

collMod 把 validationAction 从 warn 改为 error，然后分别插入
"缺必填字段"与"字段类型错误"的文档，验证 Schema 校验生效；
演示后改回 warn，并清理测试文档。
输出：/root/out_validate.txt
"""
import io

from pymongo import MongoClient
from pymongo.errors import WriteError

lib = MongoClient("mongodb://root:Root%402026@127.0.0.1:27017/?authSource=admin",
                  serverSelectionTimeoutMS=5000)["library"]
out = []


def p(*a):
    line = " ".join(str(x) for x in a)
    print(line)
    out.append(line)


p("########## books 集合的 Schema 校验（ST-2.1 建模增强） ##########")
p("当前规则：必填字段 isbn / title / category / price / stock；")
p("          isbn 必须为字符串、stock 不能为负、rating 取值 0—5 等")
p("")
p("命令：db.runCommand({collMod: 'books', validationAction: 'error'})   # 把 warn 改为 error 才能拒绝写入")
lib.command("collMod", "books", validationAction="error")
p("  返回 ok=1，校验动作已设为 error")
p("")

cases = [
    ("缺必填字段 price / stock",
     {"isbn": "9787000000099", "title": "缺字段测试", "category": "计算机"}),
    ("isbn 用数字而不是字符串",
     {"isbn": 9787115428028, "title": "类型测试", "category": "计算机", "price": 50, "stock": 3}),
    ("stock 为负数",
     {"isbn": "9787000000098", "title": "负库存测试", "category": "计算机", "price": 50, "stock": -1}),
]
for desc, doc in cases:
    p("---- 插入 %s ----" % desc)
    p("  文档：%s" % doc)
    try:
        lib.books.insert_one(dict(doc))
        p("  !! 插入成功（校验未生效）")
    except WriteError as e:
        p("  写入被拒绝（Document failed validation）：")
        p("    %s" % (e.details.get("errmsg", str(e)).replace("\n", " ")[:220]))

p("")
p("---- 合法文档照常写入 ----")
lib.books.insert_one({"isbn": "9787000000097", "title": "类型与字段都合法的测试书", "author": "测试",
                      "publisher": "测试出版社", "category": "计算机", "price": 59.0, "stock": 2,
                      "rating": 4.5, "tags": ["测试"], "borrow_count": 0})
p("  合法文档插入成功，books 文档数 = %s" % lib.books.count_documents({}))
lib.books.delete_one({"isbn": "9787000000097"})
p("  清理测试文档后 books 文档数 = %s" % lib.books.count_documents({}))
p("")
lib.command("collMod", "books", validationAction="warn")
p("命令：db.runCommand({collMod: 'books', validationAction: 'warn'})   # 演示结束，恢复为 warn")
p("  （warn 表示不合规文档仍可写入，但会在 mongod 日志中留下告警，方便开发阶段排查）")

io.open("/root/out_validate.txt", "w", encoding="utf-8").write("\n".join(out) + "\n")
