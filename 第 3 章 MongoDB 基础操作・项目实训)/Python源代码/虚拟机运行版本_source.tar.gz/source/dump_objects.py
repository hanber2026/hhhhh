﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
导出数据库对象定义（索引 / 视图 / 固定集合 / 时间序列 / 账号角色）到交付目录，
用于"数据文件或数据库备份"之外，说明三类特殊集合是怎么建的。
"""
import io
import os

from pymongo import MongoClient

URI = ("mongodb://libWriter:Writer%402026@127.0.0.1:27017/?authSource=library")
OUT = "/root/backup/objects.json"

client = MongoClient(URI, serverSelectionTimeoutMS=5000)
db = client["library"]

objects = {}
for info in db.list_collections():
    name = info["name"]
    if name.startswith("system."):
        continue
    objects[name] = {
        "type": info.get("type", "collection"),
        "options": {k: str(v) for k, v in info.get("options", {}).items()},
        "indexes": [],
    }
    if info.get("type") == "view":
        continue
    for idx in db[name].list_indexes():
        objects[name]["indexes"].append({"name": idx["name"], "key": dict(idx["key"]), "unique": bool(idx.get("unique", False))})

with io.open(OUT, "w", encoding="utf-8") as f:
    import json
    json.dump(objects, f, ensure_ascii=False, indent=2, default=str)
print("written", OUT)
for k, v in objects.items():
    print("%-16s %-12s %s" % (k, v["type"], [i["name"] for i in v["indexes"]]))
