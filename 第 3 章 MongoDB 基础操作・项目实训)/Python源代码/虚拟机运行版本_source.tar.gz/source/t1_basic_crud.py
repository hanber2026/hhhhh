#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ST-5.1  图书情报检索与统计平台 —— PyMongo 基础连接与增删改查
文件：t1_basic_crud.py
运行：python3 t1_basic_crud.py      （需先在 MongoDB 中创建 library 库、books 集合和 libWriter 账号）
说明：本程序演示 MongoClient 连接、database/collection 对象获取、ping 心跳检测，
      以及图书文档的“增、删、改、查”四类基本操作。
"""
import sys
from urllib.parse import quote_plus
import datetime
import pymongo
from pymongo import MongoClient
from bson import ObjectId

# ---------------------------------------------------------------- 连接参数
URI = ("mongodb://libWriter:%s@127.0.0.1:27017/?authSource=library" % quote_plus("Writer@2026"))
DB_NAME = "library"

PY = sys.version.split()[0]
print("=" * 72)
print(" ST-5.1  PyMongo 基础连接与增删改查    (Python %s / PyMongo %s)" % (PY, pymongo.version))
print("=" * 72)

# ---------------------------------------------------------------- 1. 建立连接
print("\n[1] 建立连接")
client = MongoClient(URI, serverSelectionTimeoutMS=5000, appname="lib-platform")
print("  MongoClient  : %s" % client)
print("  服务端版本   : %s" % client.server_info()["version"])
print("  ping 结果    : %s" % client.admin.command("ping"))

# 获取 database 与 collection 对象（惰性创建，首次写入时才真正建库建集合）
db = client[DB_NAME]
books = db["books"]
print("  当前数据库   : %s" % db.name)
print("  集合对象     : %s" % books.full_name)
print("  已有集合     : %s" % sorted(db.list_collection_names()))

# ---------------------------------------------------------------- 2. 增 Create
print("\n[2] 增 —— 插入文档")
before = books.count_documents({})
new_book = {
    "isbn": "9787000000001",
    "title": "PyMongo 实战指南",
    "author": "图书馆信息中心",
    "publisher": "计算机学院出版社",
    "category": "计算机",
    "price": 79.0,
    "stock": 12,
    "rating": 4.6,
    "tags": ["编程", "数据库", "NoSQL"],
    "publish_date": datetime.datetime(2024, 3, 1),
    "borrow_count": 0,
}
r1 = books.insert_one(new_book)
print("  insert_one   -> inserted_id = %s (类型 %s)" % (r1.inserted_id, type(r1.inserted_id).__name__))

r2 = books.insert_many([
    {"isbn": "9787000000002", "title": "数据新闻与统计图表", "author": "王晓",
     "publisher": "计算机学院出版社", "category": "经济管理", "price": 68.0,
     "stock": 6, "rating": 4.2, "tags": ["统计", "可视化"], "borrow_count": 2},
    {"isbn": "9787000000003", "title": "信息检索导论（第2版）", "author": "李澜",
     "publisher": "计算机学院出版社", "category": "计算机", "price": 88.0,
     "stock": 4, "rating": 4.4, "tags": ["检索", "入门"], "borrow_count": 5},
])
print("  insert_many  -> %d 条, inserted_ids = %s" % (len(r2.inserted_ids), r2.inserted_ids))
print("  文档数       : %d -> %d" % (before, books.count_documents({})))

# ---------------------------------------------------------------- 3. 查 Read
print("\n[3] 查 —— 各类查询")
one = books.find_one({"isbn": "9787000000001"})
print("  find_one     : %s / %.2f 元 / 库存 %d" % (one["title"], one["price"], one["stock"]))

cur = books.find({"category": "计算机", "stock": {"$gte": 5}},
                 {"_id": 0, "title": 1, "stock": 1, "price": 1}).sort("price", -1)
print("  find 投影+排序 （计算机类且库存>=5，按价格降序）:")
for d in cur:
    print("      %-26s 库存 %2d  %6.2f 元" % (d["title"], d["stock"], d["price"]))

print("  count_documents({})            = %d" % books.count_documents({}))
print("  count_documents(category=文学) = %d" % books.count_documents({"category": "文学"}))
print("  distinct(category)             = %s" % books.distinct("category"))
print("  estimated_document_count()     = %d" % books.estimated_document_count())

# ---------------------------------------------------------------- 4. 改 Update
print("\n[4] 改 —— 更新文档")
u1 = books.update_one({"isbn": "9787000000001"}, {"$set": {"stock": 8}, "$currentDate": {"updated_at": True}})
print("  update_one   -> matched=%d modified=%d" % (u1.matched_count, u1.modified_count))
u2 = books.update_many({"publisher": "计算机学院出版社"}, {"$inc": {"borrow_count": 1}})
print("  update_many  -> matched=%d modified=%d" % (u2.matched_count, u2.modified_count))
u3 = books.find_one_and_update({"isbn": "9787000000003"},
                               {"$push": {"tags": "教材"}},
                               return_document=pymongo.ReturnDocument.AFTER,
                               projection={"_id": 0, "title": 1, "tags": 1})
print("  find_one_and_update -> %s" % u3)

# ---------------------------------------------------------------- 5. 删 Delete
print("\n[5] 删 —— 删除文档")
d1 = books.delete_one({"isbn": "9787000000002"})
print("  delete_one   -> deleted=%d" % d1.deleted_count)
d2 = books.delete_many({"isbn": {"$regex": r"^978700000000"}})
print("  delete_many  -> deleted=%d （清理本次演示插入的全部测试数据）" % d2.deleted_count)
print("  文档数       : %d （与演示前一致，说明增删闭环成立）" % books.count_documents({}))

# ---------------------------------------------------------------- 6. 关闭
print("\n[6] 关闭连接")
client.close()
print("  client.close() 完成，程序正常结束")
