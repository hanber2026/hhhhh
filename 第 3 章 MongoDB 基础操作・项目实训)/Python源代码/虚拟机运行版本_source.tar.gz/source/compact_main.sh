#!/usr/bin/env bash
# 任务五 输出压缩：合并「菜单」重复出现（只保留前两次），供文档/报告引用
export LANG=C.UTF-8 LC_ALL=C.UTF-8
cd /root/source || exit 1
python3 - <<'PY'
import re
src = open('/root/out_main_demo.txt', encoding='utf-8').read()
# 菜单块：从 "+---" 开始到 "请选择功能编号（0 退出）：" 结束
menu = re.compile(r'\+-{70,}\+\n\| +图书情报检索与统计平台.{0,2000}?请选择功能编号（0 退出）：', re.S)
blocks = list(menu.finditer(src))
print("菜单出现次数：", len(blocks))
out, last = [], 0
for i, m in enumerate(blocks):
    out.append(src[last:m.start()])
    if i < 2:
        out.append(m.group(0))
    else:
        out.append("[菜单]（同上，共 16 项功能，输入对应编号）\n请选择功能编号（0 退出）：")
    last = m.end()
out.append(src[last:])
res = "".join(out)
open('/root/out_main_compact.txt', 'w', encoding='utf-8').write(res)
print("原始 %d 字符 → 压缩 %d 字符" % (len(src), len(res)))
PY
head -20 /root/out_main_compact.txt
echo "..."
grep -c "菜单" /root/out_main_compact.txt
